import { ApplicationConfig } from '@angular/core';

// HttpClient provider is no longer needed for a frontend-only demo
export const appConfig: ApplicationConfig = {
  providers: []
};
